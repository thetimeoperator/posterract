# Editing workflow

## Orient

```sh
posterract doctor --json
posterract open /absolute/path/to/project --background
posterract context --json
```

Read the project instructions, manifest, entry TSX, and relevant local SDK docs. Identify the active scene ID, dimensions, FPS, duration/work area, source media, and deliverable.

## Inspect source media

```sh
posterract media probe assets/video/source.mp4
posterract media filmstrip assets/video/source.mp4 --output /tmp/source-filmstrip.png
posterract media waveform assets/video/source.mp4 --output /tmp/source-waveform.png
posterract media grab assets/video/source.mp4 --auto --count 12 --output /tmp/source-frames
```

Inspect the resulting images. Use `media extract` only to create a small local segment for the connected agent's own transcription or listening capabilities.

## Edit incrementally

- One `<stage>` owns the project workspace.
- Each top-level `<scene>` is one independently exportable video.
- Use `<sequence>` for timed chapters or clip groups inside a scene.
- Preserve stable IDs.
- Keep each change small enough to diagnose.

After every meaningful change:

```sh
posterract validate --json
posterract check main --json
posterract capture main --time 0 1.5 3 --output /tmp/posterract-check
```

Open every capture. A passing structural check does not prove that footage pixels are visible or attractive.

## Finish

Only after explicit instruction:

```sh
posterract export main --output /absolute/project/path/exports/final.mp4
```

Export remains local. Posting and scheduling are separate authenticated Posterract cloud actions.
