# Installation

## Desktop and CLI

1. Install and launch Posterract Desktop.
2. In Posterract, choose **Posterract → Install Command Line Tool…** on macOS or **File → Install Command Line Tool…** on Windows/Linux.
3. Open a new terminal.
4. Run `posterract version`.
5. Run `posterract doctor --json`.

If the installer uses `~/.local/bin`, add it to `PATH` and open a new terminal.

## Agent skill

- Codex: copy the `posterract-skill` folder into the configured Codex skills directory and restart/reload skills.
- Claude Code: place the folder where the project or user-level Claude skills configuration can read it.
- Cursor: add the skill folder to the agent rules/skills location used by the workspace.
- Generic coding agent: provide `SKILL.md` as the entry instructions and preserve the relative `references/` and `examples/` folders.

Verify the ZIP checksum before extracting. The `manifest.json` version ranges must include the installed desktop, CLI, SDK, and protocol versions.

Project-local `.posterract/docs` always overrides copied skill summaries when APIs differ.
