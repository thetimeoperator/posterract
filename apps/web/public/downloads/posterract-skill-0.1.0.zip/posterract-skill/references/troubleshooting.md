# Troubleshooting

## App or bridge unavailable

```sh
posterract doctor --json
posterract open /absolute/path/to/project --background
```

If protocol versions differ, update the desktop app and reinstall the CLI from its menu.

## Project not open

Run `posterract open <absolute-project-path> --background`, then rerun `context`. `open` must not return until the project is mounted.

## Validation failure

Read diagnostics, the entry TSX, and `.posterract/docs/lifecycle-errors.md`. Fix the smallest source error, save, and rerun validation. The editor preserves the last successfully mounted canvas.

## Source revision conflict

Reread the newest `src/index.tsx`, locate the element by stable ID, and reapply the semantic edit. Never overwrite the newer file wholesale.

## Missing asset

Check `assets.yml`, probe the path, relink or replace the source, then regenerate the relevant cache artifact. Do not delete the original file.

## Structural check passes but frame looks wrong

Capture the suspicious exact times. `check` reports scheduling and visibility structure, not whether the underlying pixels are dark or aesthetically correct.

## Diagnostic bundle

```sh
posterract report --output /tmp/posterract-report.zip
```

The report is local and sanitized. It does not upload or create an issue automatically.
