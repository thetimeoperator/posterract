---
name: posterract
description: Build, inspect, validate, capture, and export local Posterract TSX video compositions with the Posterract Desktop CLI. Use when an agent works in a Posterract project, edits @posterract/composition source, analyzes local media, or prepares a local export for an explicitly requested post or schedule action.
---

# Posterract

Work from the local project folder. Treat `src/index.tsx` as canonical and the active project's `.posterract/docs` as authoritative for the installed SDK version.

## Required workflow

1. Run `posterract doctor --json`.
2. Open the project with `posterract open <project-path> --background` if necessary.
3. Read `AGENTS.md`, `README.md`, `package.json`, `assets.yml`, and the relevant `.posterract/docs` pages.
4. Run `posterract context --json`; add `--tree` only when debugging a source/runtime mismatch.
5. Read `src/index.tsx` before changing it.
6. Probe source media with `posterract media probe <asset-or-path>`.
7. Generate filmstrips, waveforms, or representative frame grabs when they clarify the edit.
8. For nontrivial work, write a short creative brief before editing.
9. Assemble primary footage first, then secondary footage, captions, audio, overlays, effects, and transitions.
10. Organize timed material into `<sequence>` elements. One top-level `<scene>` is one independently exportable video.
11. Hoist important creative controls into documented inspector variables.
12. Make a small source change and save it.
13. Run `posterract validate --json`.
14. Run `posterract check <scene-id> --json`.
15. Run `posterract capture <scene-id> --time <times...>` and inspect every returned image.
16. Repeat incrementally until validation, structural checks, and inspected captures agree.
17. Export only after the user explicitly requests an export.
18. Post or schedule only after a separate explicit user instruction.

## Non-negotiable safety

- Never claim visual verification without opening the capture output.
- Never post or schedule merely because an export finished.
- Never upload imported or raw project media automatically.
- Never request, print, or store social OAuth tokens, desktop session tokens, or provider secrets.
- Never overwrite a concurrent source revision; stop on a reported revision conflict.
- Never edit `.posterract/sdk` or `.posterract/docs`.
- Never delete source media without explicit authorization.
- Never hide validation, check, capture, or export failures.
- Keep generated inspection artifacts local and outside source folders unless the user asks otherwise.

## Reference routing

- Installation and compatibility: `references/installation.md`
- Full editing loop: `references/workflow.md`
- TSX model and local docs: `references/composition-sdk.md`
- Exact CLI command map: `references/cli.md`
- Efficient video/audio inspection: `references/media-analysis.md`
- Easing guidance: `references/easings.md`
- Recovery steps: `references/troubleshooting.md`
- Export-to-publish boundary: `references/posting-api.md`

Load only the references needed for the current task. Use the examples as patterns, then verify actual supported properties against the project's local SDK docs.
